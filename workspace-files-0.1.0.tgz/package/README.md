# dsh-workspace-files

在 Web GUI 中浏览会话工作区的目录/文件，并结合 Git 显示文件改动（行级 diff）。

## 安装

### 一、打包（在本仓库根目录）

```powershell
pnpm pack
```

### 二、安装到 web profile

```powershell
dsh plugin --profile web add "workspace-files-0.1.0.tgz"
```

### 三、生效

重启 `dsh web`（或刷新已重启的 GUI）。打开一个会话，内容区顶部 tab 栏出现第三个「文件」tab（与「对话 / 轨迹」并列）。
点击进入：左侧目录树（带 git 状态角标 M/A/D/?），右侧文件内容；对有改动的文件可切换「内容 / 改动」查看行级 diff。
工作区根由前端用当前 `sessionId` 调 host 路由 `/api/workspace-files/session-root` 解析（host 侧读会话 header 的 cwd），无需手动选择。

### 卸载

```powershell
dsh plugin --profile web remove workspace-files
```

## 已验证

- host `/api/workspace-files/session-root`：按 `sessionId` 解析会话工作区根（读 `sessionPersistence` 的 header cwd）。
- host `/api/workspace-files/list|read`：目录列举、文件读取、路径穿越返回 403。
- host `/api/workspace-git/is-repo|status|diff`：仓库探测、status 解析、tracked/untracked 文件的行级 diff。
- 非 git 目录 / git 缺失：`is-repo` 返回 `false`，前端自动隐藏 diff 入口（优雅降级）。
- 客户端 bundle 经 `/plugins/workspace-files/client.js` 正确下发，并出现在启动清单中。
- 单包同时声明 `dsh.bundle` 与 `dsh.client`：安装即被识别为 bundle 并激活，同一行 patch 双面工作（host apply + client UI）。

## 后续可做

- 语法高亮（引入 shiki，目前为纯文本 `<pre>`）。
- diff 的 split（并排）视图。
- 目录树中对超大目录的分页/懒加载增强（当前单层上限 2000 条）。
